# Report Workflow

This Agent Skill is interactive and platform-neutral. The agent must not proceed to formal report generation until the client confirms the chapter outline and the data source plan.

## Gate 1: Font Preflight

Run:

```bash
python scripts/font_preflight.py
```

If the required Chinese weights are available, continue to the brief interview. If not, tell the user:

- Which weights are missing
- Which fallback fonts are available
- How the report will visually differ

## Gate 2: Brief Interview

Use this concise interview when the user has not already provided enough detail:

```text
为了先把报告方向定准，我需要确认以下信息：
1. 报告主题与核心决策问题是什么？
2. 目标读者是谁？他们会用这份报告做什么决定？
3. 期望报告深度/页数大概是多少？
4. 你已经有哪些材料或数据？哪些内容需要保密？
5. 数据来源希望使用你提供的资料、公开资料，还是两者结合？
6. 是否有必须引用或禁止引用的来源？
7. 输出格式是否只要 PDF，还是还需要中间稿/图表数据？
```

Ask fewer questions when the answer is already present in the user request or files.

## Gate 3: Chapter Confirmation

After the brief, propose a custom outline. Do not use a fixed industry-report template. Use this structure:

```text
基于当前 brief，我建议报告采用以下章节：

1. <章节名>
   - 作用：<为什么需要这一章>
   - 决策问题：<本章回答什么问题>
   - 所需资料/数据：<需要哪些数据/访谈/材料>
   - 可能展品：<图表或框架类型>

请确认这个章节结构是否可以继续；也可以告诉我需要删除、合并或调整的章节。
```

Stop here. Wait for explicit user confirmation or revision before moving on.

## Gate 4: Data Source Confirmation

Once the outline is confirmed, produce a data plan:

```text
下面是数据来源确认表：

| 章节 | 关键问题/结论 | 所需数据 | 建议来源 | 需要你确认 |
|---|---|---|---|---|
| ... | ... | ... | 用户资料/公开资料/估算 | 是否有资料或允许公开检索 |
```

Ask whether the user has these sources or wants public research. If public research is needed, confirm acceptable source types such as official statistics, company filings, industry associations, consulting reports, academic papers, and reputable financial media.

## Production Sequence After Confirmation

1. Create storyline/storyboard.
2. Build page-level claims, evidence, implications, and source support internally.
3. Rewrite the internal analysis into client-facing consulting whitepaper prose. Use fluent paragraphs and professional section headings; do not expose analysis-process labels in the final PDF.
4. Use a stable left-aligned main text axis for client-facing body pages and chapter-intro prose. Wrap text by rendered width rather than fixed character counts.
5. Generate exhibits with direct labels, notes, sources, and 1-2 client-readable interpretation points.
6. Generate the contents page with actual page numbers once the page structure is final.
7. Use full-page chapter intros only where they improve reading rhythm; smaller chapters may begin on a chapter-labeled body or exhibit page.
8. Convert long portrait tables into card grids, split pages, or landscape pages before PDF generation.
9. Generate PDF under the active workspace output folder. Prefer `03-outputs/consulting-report/<run-name>/final/report.pdf` when that folder exists; otherwise use `outputs/consulting-report/<run-name>/final/report.pdf`.
10. Render selected pages for visual QA, including contents, chapter-intro text, dense table/card pages, heatmaps, and exhibit pages with interpretation text.
11. Report final paths and any remaining assumptions.

## Client-Facing Prose Rule

The report may use structured thinking internally, but the final PDF must read like a polished whitepaper for the target audience. Avoid visible labels such as `证据：`, `含义：`, `逻辑链条`, `事实基础`, `对客户启示`, `本章逻辑`, and `竞品`. Convert them into concise subheads and natural paragraphs, for example:

- `证据 + 含义` becomes one or two paragraphs that move from fact to interpretation.
- `事实基础 / 逻辑链条 / 对客户启示` becomes client-facing sections such as `市场表现`, `战略打法`, and `行业启示`.
- `本章逻辑` becomes `章节导读`.
